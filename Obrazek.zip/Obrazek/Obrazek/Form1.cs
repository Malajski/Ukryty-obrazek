﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Obrazek
{
    public partial class Form1 : Form
    {
        Graphics g;       // deklaracja kanwy
        Pen p = new Pen(Color.SeaGreen, 5);      // deklaracja i tworzenie pióra
        SolidBrush bs = new SolidBrush(Color.WhiteSmoke);     // deklaracja i tworzenie pędzla gładkiego
        static Bitmap wzorek = (Bitmap)Image.FromFile("zwierze.png", true);     // wzór dla pedzla teksturowego
        TextureBrush bt = new TextureBrush(wzorek);      // deklaracja i tworzenie pędzla teksturowego
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            g = this.CreateGraphics();

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            int x = e.X;        // odczyt współrzędnych myszy
            int y = e.Y;
            if (e.Button == MouseButtons.Left) g.FillEllipse(bs, x - 30, y - 30, 60, 60);     // lewy klawisz - gładki pędzel
            if (e.Button == MouseButtons.Right) g.FillEllipse(bt, x - 30, y - 30, 60, 60);     // prawy klawisz - wzorzysty pędzel
        }

        private void wyjścieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pusheenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://pusheen.com");
         
        }

        private void autorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Łukasz Niedźwiadek ©IIIB 2018", "Autor", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void informacjeOProgramieToolStripMenuItem_Click(object sender, EventArgs e)
        {

          
            

        }

        private void informacjeOProgramieToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Form2 info = new Form2();
            info.Show();
        }

        private void gitHubToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://github.com/Malajski/Ukryty-obrazek");
        }
    }
}
